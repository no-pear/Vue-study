import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _349930e7 = () => interopDefault(import('..\\pages\\layout' /* webpackChunkName: "" */))
const _38e91448 = () => interopDefault(import('..\\pages\\home' /* webpackChunkName: "" */))
const _e3c8e3e8 = () => interopDefault(import('..\\pages\\login' /* webpackChunkName: "" */))
const _4e970b8c = () => interopDefault(import('..\\pages\\profile' /* webpackChunkName: "" */))
const _158a76a0 = () => interopDefault(import('..\\pages\\settings' /* webpackChunkName: "" */))
const _28ca572a = () => interopDefault(import('..\\pages\\editor' /* webpackChunkName: "" */))
const _35614ed9 = () => interopDefault(import('..\\pages\\article' /* webpackChunkName: "" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _349930e7,
    children: [{
      path: "",
      component: _38e91448,
      name: "home"
    }, {
      path: "/login",
      component: _e3c8e3e8,
      name: "login"
    }, {
      path: "/register",
      component: _e3c8e3e8,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _4e970b8c,
      name: "profile"
    }, {
      path: "/settings",
      component: _158a76a0,
      name: "settings"
    }, {
      path: "/editor",
      component: _28ca572a,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _35614ed9,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
