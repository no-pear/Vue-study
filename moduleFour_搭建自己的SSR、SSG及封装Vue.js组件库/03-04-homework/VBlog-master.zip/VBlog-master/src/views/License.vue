<template>
    <div>
        <el-card shadow="never" style="min-height: 400px;margin-bottom: 20px;padding: 20px 0px 20px 0px;text-align: center">
            <font style="font-size: 30px;color:#dddddd ">
                <b>◔ ‸◔？</b>
            </font>
        </el-card>
    </div>
</template>
<script>

    export default {
        data() {
            return {

            }
        },
        mounted() {

        },
        methods: {

        }
    }
</script>