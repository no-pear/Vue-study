<template>
	<div style="border-top: 1px #e1e4e8 solid !important;padding: 45px 0px 45px 0px;">
		<el-row>
			<el-col :span="10">
				<div>
					© 2018 GitHub-Laziji&emsp;&emsp;
					<a href="https://github.com/GitHub-Laziji" target="_blank">Profile</a>&emsp;&emsp;
					<a href="https://github.com/GitHub-Laziji/vblog" target="_blank">VBlog</a>
				</div>
			</el-col>
			<el-col :span="4">
				<div style="text-align: center;font-size: 18px">
					<i class="el-icon-location-outline"></i>
				</div>
			</el-col>
			<el-col :span="10">
				<div style="float: right;">
					<a href="https://developer.github.com" target="_blank">GitHub-API</a>&emsp;&emsp;
					<a href="https://cn.vuejs.org/" target="_blank">Vue.js</a>&emsp;&emsp;
					<a href="http://element.eleme.io/" target="_blank">Element</a>

				</div>
			</el-col>
		</el-row>
	</div>
</template>
<script>
	export default {
		data() {
			return {

			}
		},
		methods: {

		}
	}
</script>